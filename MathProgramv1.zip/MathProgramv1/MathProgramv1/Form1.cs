﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathProgramv1
{
    public partial class Form1 : Form
    {
        string a, b, c;
        public Form1()
        {
            InitializeComponent();
         

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            comboBox1.Items.Add("a");
            comboBox1.Items.Add("b");
            comboBox1.Items.Add("c");
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "a")
            {
                textBox1.Text = "Podaj bok b";
                textBox3.Text = "Podaj bok c";

            }
            else if (comboBox1.SelectedItem.ToString() == "b")
            {
                textBox1.Text = "Podaj bok a";
                textBox3.Text = "Podaj bok c";

            }
            else if (comboBox1.SelectedItem.ToString() == "c")
            {
                textBox1.Text = "Podaj bok a";
                textBox3.Text = "Podaj bok b";

            }


        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a =0, b =0,c=0;
            try { 
                if (comboBox1.SelectedItem.ToString() == "c")
                {
                    a = Double.Parse(textBox2.Text);
                    b = Double.Parse(textBox4.Text);
                    if ((b <= 0) || (a <= 0))
                    {
                        MessageBox.Show("Błąd Danych", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                        
                    textBox5.Text = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2)).ToString();
         
                }
                
                else if (comboBox1.SelectedItem.ToString() == "b")
                {
                   a = Double.Parse(textBox2.Text);
                   c = Double.Parse(textBox4.Text);
                    if ((c <= 0) || (a <= 0))
                    {
                        MessageBox.Show("Błąd Danych", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
           
                    }
                    if (c > a)
                        textBox5.Text = Math.Sqrt(Math.Pow(c, 2) - Math.Pow(a, 2)).ToString();
                    else
                    {
                        MessageBox.Show("Z podanych danych nie da się stworzyć trójkąta.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
           
                }

                else if (comboBox1.SelectedItem.ToString() == "a")
                {
                    b = Double.Parse(textBox2.Text);
                    c = Double.Parse(textBox4.Text);
                    if ((c <= 0) || (b <= 0))
                    {
                       MessageBox.Show("Błąd Danych", "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    if (c > b)
                        textBox5.Text = Math.Sqrt(Math.Pow(c, 2) - Math.Pow(b, 2)).ToString();
                    else
                    {
                        MessageBox.Show("Z podanych danych nie da się stworzyć trójkąta.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                }
            catch (Exception ex)
            {
                textBox5.Text = "";
                MessageBox.Show(ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void wyjdźToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void autorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Łukasz Niedźwiadek IIIB 2018", "Copyright",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void plikToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void enter(object sender, KeyPressEventArgs e)
        {
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://pl.wikipedia.org/wiki/Twierdzenie_Pitagorasa");       
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
  
        }
    }
}
